##NOTA DE CONSIDERAÇÃO
##Olá! Eu sou um iniciante em pygame e ggostaria de
##utilizar desse espaço para algumas declarações.
##Devo dar nota que o teclado está quebrado
##(para sofrimento único e exclusivo meu, claro).
##A primeira coisa é: pygame não é uma engine convidativa.
##A forma de instalação (em pip), pode ser comum  para dev's
##que trabalham em python, mas não é nada fácil para um
##iniciante. A forma de aplicação das funções e a falta de
##praticiade em muitas delas é muitoo desconfortavel e complexa
##de forma desnecessária muita das vezes(ao meu ver).
##Tendo adicionado isso durante a criação desse projeto, espero que,
##com o tempo e com mais experiência, no futuro próximo eu possa tirar
##essa nota de dor e pesar.
##
##Aqui também deixo meus agradecimentos aos tutoriais no youtube,
##aos deuuses ddos forruns e um agrradecimentto especial para todos os
##senhores e senhoras do stackoverflow (principalmente os do pt. S2 amo vcs).
##
##ass. Um Dev Noob.

##Adaptação para o codigo funcionando sem o modulo pygame

##TEXTOS

t_tutorial='''Utilize o teclado númerico no jogo.\n
COMFIRME UM NÚMERO ENTRE 1 E 9 PARA CONTINUAR OU 0 PARA SAIR'''
t_intro1='''16 de agosto de 1919. Hoje eu me apressei para com os\n
eventos diários, já que ao final da tarde eu teria um\n
compromisso. Hoje é o aniversário de meu caro amigo\n
Elliot, quem não vejo a muito, e eu fui convidado para a sua\n
festa de aniversário, nos jardins de sua magnífica\n
propriedade familiar, uma casa de campo no Bayou. Uma\n
viagem de avião é deveras exaustante, mas não há nada\n
que eu não possa fazer por ele. Elliot já é amigo a muito\n
tempo, desde os tempos de colégio e faculdade, em\n
Boston. Ambos seguimos o direito, mas por ramos\n
diferentes. Ele decidiu ser um policial, e hoje vive nessa\n
quente e úmida cidade, junto a sua esposa. Após finalizar\n
meu serviço de sábado, fui buscar uma forma de seguir o\n
caminho. Uma carroça foi a forma mais prática encontrada\n
para percorrer por aquelas estradas irregulares e cheias de\n
buracos.\n
DIGITE UM NÚMERO ENTRE 1 E 9 PARA CONTINUAR OU 0 PARA SAIR'''

t_intro2='''A tarde foi revigorante. O almoço sob as árvores e a\n
música alegrou o lugar, tornando a tarde mais refrescante.\n
Casais dançaram pelo pátio externo, incluindo Elliot e sua\n
esposa, Carmem. Como ele já tinha me descrito: Carmem\n
estava linda e sorridente, dançando levemente nos braços\n
dele. Seus olhos tinham um brilho jovial, mas um tanto\n
misterioso. Não esperava nada de diferente, já que Elliot\n
sempre gostou de mistérios. Mas chamou ainda mais\n
atenção o discurso... &quot;Enfático&quot;, se podemos dizer assim,\n
do pai de Elliot, Adam, ou como ele prefere, Coronel Ferri.\n
Altivo, sério e com um tom autoritário e intimidador, ele fez\n
um discurso curto, típico de um ex-militar. Um rosto severo,\n
com rugas de preocupação, apesar de não ser tão velho.\n
Um bigode grande e largo completava aquela face\n
conhecida e temida. Antes do almoço ele fez o seu\n
discurso, parabenizando Elliot por seu aniversário e pela\n
sua promoção recente para o cargo de investigador chefe\n
na polícia de Nova Orleans.\n
DIGITE UM NÚMERO ENTRE 1 E 5 PARA CONTINUAR OU 6 PARA SAIR'''

t_intro3='''Seguido do almoço, Elliot me chamou a um reservado,\n
apresentando sua família a mim devidamente. Já conhecia\n
a muito seu pai, contudo, a mim foi apresentada a sua nova\n
esposa, Veronica. Uma mulher jovem, seria como o pai de\n
Elliot, porém com um ar mais gracioso que apenas uma\n
dama pode deter. Ele também me convidou para participar\n
do jantar daquela noite, ainda ali, na propriedade,\n
destinado apenas a pessoas próximas e familiares. Apesar\n
das pesadas nuvens no céu, decidi ficar.\n
DIGITE UM NÚMERO ENTRE 1 E 5 PARA CONTINUAR OU 6 PARA SAIR'''

t_intro4='''O jantar decorreu de uma forma mais branda, lenta e\n
solene. As pessoas conversavam de forma baixa, mas\n
ocorreu um problema. Com o decorrer do jantar, tais vinhos\n
e carnes me destrairam, e acabei não percebendo a\n
tempestade que se aproximava. Ao fim do jantar, a estrada\n
de volta era um grande lamaçal e, como previsto, eu não\n
tinha uma forma de voltar a cidade. Elliot e Carmem se\n
ofereceram a me abrigar naquele dia, me oferecendo o\n
quarto de hóspedes. Uma gentileza indescritível.\n
DIGITE UM NÚMERO ENTRE 1 E 5 PARA CONTINUAR OU 6 PARA SAIR'''

t_intro5='''Aproveitamos a noite, já que eu dormiria lá. Tomamos chá\n
com biscoitos, preparado por Carmem e Veronica,\n
conversamos sobre o tempo que ficamos separado, o que\n
fizemos depois da faculdade e o dia a dia no trabalho,\n
apesar dos dias dele serem mais interessante. Próximo da\n
hora de nos recolhermos, quando Carmem já tinha\n
preparado o banho para Elliot se deitar, houve uma\n
inesperada queda de energia, já que a tempestade já tinha\n
enfraquecido. No desespero, batemos em móveis ao tentar\n
circular pela sala e procurar velas e lamparinas. Depois de\n
algum tempo, escuto um urro vindo do meio da sala e um\n
baque. Rapidamente, passando as mãos por dentro das\n
gavetas, eu encontro velas e algumas caixas de fósforo,\n
mas, assim que acendo o pavio escuto o grito de Veronica\n
e vejo Carmem cair ao meu lado. Ao olhar para trás, vejo\n
no chão da sala o corpo de Elliot, meu amigo de tanto\n
tempo, estendido no chão frio, pálido e morto.\n
DIGITE UM NÚMERO ENTRE 1 E 5 PARA CONTINUAR OU 6 PARA SAIR'''

t_living='''Todos ainda estão na sala, contudo,\n
afastados do corpo e dos móveis na sala temos apenas um sofá,\n
uma poltrona, uma estante e… o corpo dele.'''

t_kitchen='''A cozinha está vazia.\n
Alguns armário, uma mesa e o fogão ainda quente'''

t_bath='''O banheiro é um pouco apertado.\n
Uma ducha, um vaso, a pia e um  pequeno armário.'''

t_bed1='''O quarto principal é grande, mas\n
tem  poucos elementos: a cama, um guarda roupa e criados  mudos.\n
Estamos em  uma casa de campo, afinal.'''

t_bed2='''O quarto de hóspedes é um pouco apertado e têm\n
poucos elementos: a cama, um guarda roupa e criados  mudos.\n
Estamos em  uma casa de campo, afinal.'''

t_end1='''Depois da noite, tentei juntar as peças. Pensei bastante. O\n
resultado...\n
Foi inútil. Sem provas, não pude encontrar o assassino.\n
A culpa me consome até hoje. Me perdoe, Elliot...'''

t_end2='''Depois da noite, tentei juntar as peças. Pensei bastante. O\n
resultado...\n
Foi único. As provas me levaram a pensar em apenas\n
um culpado: Adam Ferri. Apesar de ser pai de Elliot,\n
tudo levava a ele. Ainda havia pontas soltas, mas nem\n
eu nem a polícia chegamos a algum resultado. Adam\n
foi preso e condenado pelo assassinato de Elliot Ferri,\n
cometido na noite de 16 de agosto de 1919.'''

t_end3='''Depois da noite, tentei juntar as peças. Pensei bastante. O\n
resultado...\n
Foi único. As provas me levaram a pensar em apenas\n
uma culpada: Carmem Ferri. Apesar de ser esposa de\n
Elliot, tudo levava a ela. Ainda havia pontas soltas, mas\n
nem eu nem a polícia chegamos a algum resultado.\n
Carmem foi presa e condenada pelo assassinato de\n
Elliot Ferri, cometido na noite de 16 de agosto de 1919.'''

t_end4='''Depois da noite, tentei juntar as peças. Pensei bastante. O\n
resultado...
'''
t_endT='''Depois da noite, tentei juntar as peças. Pensei bastante. O\n
resultado...
'''

t_body='''O que aconteceu com ele? Quem poderia ter feito isso?!\n
Ele parece ter uma ferida... Um corte nas costas... Parece...\n
Não sei, não parece fatal...'''
t_mv_bookcs='''Livros, bibelôs e pastas. Era típico dele ser\n
desorganizado...'''
t_mv_desk='''Brachela de chá e alguns biscoitos. Nada de\n
mais.'''
t_mv_cabinet='''Cerais e grãos. Algumas latas também. Parece que tem\n
o bastante pra muito tempo.'''
t_mv_cooker='''Cinzas e... '''
t_mv_sink='''Nenhuma goteira por aqui.'''
t_mv_bed='''Lençóis esticados e bem arrumados. Perfeito.'''
t_mv_wardrobe='''Não tem nenhuma peça. Vazio, como pensei.'''
t_mv_nightstand='''Vazia. Um pouco bem cuidado, mas ainda tem poeira nas\n
gavetas.'''

t_m1911='''Meu Deus! Uma M1911? Por quê isso aqui?\n
Calma... Está vazia? O pente está aqui, mas... Ainda tem\n
uma bala na agulha...'''
t_knife='''O que é isso aqui emmbaixo? Uma faca... Está cheia de\n
sangue!'''
t_flask='''"Nitroprussiato"?Eu não me lembro de Elliot\n
tomar remédios...'''
t_note1='''O quê é isso, um bilhete? "Me encontre amanhã.\n
Quero lhe ver, estou com saudades. Assinado, A"...\n
Curioso...'''
t_note2='''Papel queimado...Talvez alguém esteja escondendo algo aqui...'''
t_note3='''Uma carta. Endereçada para Veronica?\n
"Amada Veronica,\n
Não consigo mais resistir aos dias nessa casa fria.\n
Desde aquela noite não paro de pensar em você, no\n
perfume da sua pele, no calor do seu corpo. Irei me\n
afastar de Carmem se é isso que você quer. Por favor,\n
quero lhe ver novamente. Velha ao café da última vez.\n
Lhe encontrarei lá na segunda, às 10:00, e de lá\n
sairemos dessa cidade e dessa vida maldita com a\n
única coisa que importa: nós dois.\n
Com amor,\n
Elliot"\n
Mas, com a própria madrasta?!'''

##Variaveis aplicadas no jogo

a_cont=0 ##contadora de ações
itens_end_1=0
itens_end_2=0
itens_end_3=0
itens_end_4=0
itens_end_T=0

prove_m1911=0
prove_flask=0
prove_knife=0
prove_note1=0
prove_note2=0
prove_note3=0

##JOGO

##funções
def intro1():
    print(f'{t_intro1}')
    choice=(input(''))
    if choice==6:
        game_over=0
        return game_over
    else:
        if choice in '12345':
            intro2()
        else:
            print("Digite um número válido nas opções ou digite 0 para sair")
        intro1()

def intro2():
    print(f'{t_intro2}')
    choice=(input(''))
    if choice==6:
        game_over=0
        return game_over
    else:
        if choice in '12345':
            intro3()
        else:
            print("Digite um número válido nas opções ou digite 0 para sair")
            intro2()

def intro3():
    print(f'{t_intro2}')
    choice=int(input(''))
    if choice==6:
        game_over=0
        return game_over
    else:
        if choice in '12345':
            intro4()
        else:
            print("Digite um número válido nas opções ou digite 0 para sair")
            intro3()

def intro4():
    print(f'{t_intro2}')
    choice=int(input(''))
    if choice==6:
        game_over=0
        return game_over
    else:
        if choice in '12345':
            intro5()
        else:
            print("Digite um número válido nas opções ou digite 0 para sair")
            intro4()

def intro5():
    print(f'{t_intro2}')
    choice=int(input(''))
    if choice==6:
        game_over=0
        return game_over
    else:
        if choice in '12345':
            living()
        else:
            print("Digite um número válido nas opções ou digite 0 para sair")
            intro5()

############################################################################

def living():
    print(f'{t_living}')
    choice=(input('''Para onde?\n 
    1-Investigar móveis\n 
    2-Ir para a cozinha\n 
    3-Ir para o banheiro\n 
    4-Ir para o quarto principal\n 
    5-Ir para o quarto de hóspedes'''))
    if choice not in '123456':
        print("Digite um número válido nas opções ou digite 6 para sair")
        living()
    else:
        if choice==6:
            game_over=0
            return game_over
        else:
            if choice==2:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    kitchen()
            elif choice==3:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bath()
            elif choice==4:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bed1()
            elif choice==5:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bed2()
            elif choice==1:
                choice=(input("O que investigar agora?"))
                if choice not in '12346':
                    print("Digite um número válido nas opções ou digite 6 para sair")
                    living()
                else:
                    if choice==6:
                        game_over=0
                        return game_over
                    else:
                        room = 1
                        a_cont = a_cont+1
                        if a_cont==50:
                            end()
                        else:
                            return room and a_cont
                            if choice==1:
                                mv_body()
                            elif choice==2:
                                mv_bookcs()
                            elif choice==3:
                                mv_armchair()
                            elif choice==4:
                                mv_sofa()

def kitchen():
    print(f'{t_kitchen}')
    choice=(input('''Para onde?\n 
    1-Ir para a sala\n 
    2-Investigar móveis\n 
    3-Ir para o banheiro\n 
    4-Ir para o quarto principal\n 
    5-Ir para o quarto de hóspedes'''))
    if choice not in '123456':
        print("Digite um número válido nas opções ou digite 6 para sair")
        kitchen()
    else:
        if choice==6:
            game_over=0
            return game_over
        else:
            if choice==1:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    living()
            elif choice==3:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bath()
            elif choice==4:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bed1()
            elif choice==5:
                a_cont = a_cont+1
                if a_cont==50:
                    end()
                else:
                    return a_cont
                    bed2()
            elif choice==2:
                choice=(input("O que investigar agora?"))
                if choice not in '1236':
                    print("Digite um número válido nas opções ou digite 6 para sair")
                    kitchen()
                else:
                    if choice==6:
                        game_over=0
                        return game_over
                    else:
                        room=2
                        a_cont=a_cont+1
                        if a_cont==50:
                            end()
                        else:
                            return room and a_cont
                            if choice==1:
                                mv_cooker()
                            if choice==2:
                                mv_sink()
                            if choice==3:
                                mv_desk()

def bath():
    print(f'{t_bath}')
    choice=(input('''Para onde?\n 
    1-Ir para a sala\n 
    2-Ir para o cozinha\n 
    3-Investigar móveis\n 
    4-Ir para o quarto principal\n 
    5-Ir para o quarto de hóspedes'''))
    if choice not in '123456':
        print("Digite um número válido nas opções ou digite 0 para sair")
        bath()
    else:
        if choice==6:
            game_over=0
            return game_over
        else:
            if choice==1:
                living()
            elif choice==2:
                kitchen()
            elif choice==4:
                bed1()
            elif choice==5:
                bed2()
            elif choice==3:
                choice=(input("O que investigar agora?"))
                if choice not in '126':
                    print(f'Digite um número válido nas opções ou digite 6 para sair')
                    bath()
                else:
                    if choice==6:
                        game_over=0
                        return game_over
                    else:
                        room=3
                        a_cont=a_cont+1
                        if a_cont==50:
                            end()
                        else:
                            return room and a_cont
                            if choice==1:
                                mv_sink()
                            if choice==2:
                                mv_cabinet()

def bed1():
    print(f'{t_bed1}')
    choice=(input('''Para onde?\n 
    1-Ir para a sala\n 
    2-Ir para o cozinha\n 
    3-Ir para o banheiro\n 
    4-Investigar móveis\n 
    5-Ir para o quarto de hóspedes'''))
    if choice not in '123456':
        print("Digite um número válido nas opções ou digite 6 para sair")
        bed1()
    else:
        if choice==6:
            game_over=0
            return game_over
        else:
            if choice==1:
                living()
            elif choice==2:
                kitchen()
            elif choice==3:
                bath()
            elif choice==5:
                bed2()
            elif choice==4:
                choice=(input("O que investigar agora?"))
                if choice not in '1236':
                    print(f'Digite um número válido nas opções ou digite 6 para sair')
                    bed1()
                else:
                    if choice==6:
                        game_over=0
                        return game_over
                    else:
                        room=4
                        a_cont=a_cont+1
                        if a_cont==50:
                            end()
                        else:
                            return room and a_cont
                            if choice==1:
                                mv_bed()
                            if choice==2:
                                mv_wardrobe()
                            if choice==3:
                                mv_nightstand()

def bed2():
    print(f'{t_bed2}')
    choice=(input('''Para onde?\n 
    1-Ir para a sala\n 
    2-Ir para o cozinha\n 
    3-Ir para o banheiro\n 
    4-Ir para o quarto principal\n
    5-Investigar móveis'''))
    if choice not in '123456':
        print("Digite um número válido nas opções ou digite 6 para sair")
        bed2()
    else:
        if choice==6:
            game_over=0
            return game_over
        else:
            if choice==1:
                living()
            elif choice==2:
                kitchen()
            elif choice==3:
                bath()
            elif choice==4:
                bed1()
            elif choice==5:
                choice=(input("O que investigar agora?"))
                if choice not in '1236':
                    print(f'Digite um número válido nas opções ou digite 6 para sair')
                    bed2()
                else:
                    if choice==6:
                        game_over=0
                        return game_over
                    else:
                        room=5
                        a_cont=a_cont+1
                        if a_cont==50:
                            end()
                        else:
                            return room and a_cont
                            if choice==1:
                                mv_bed()
                            if choice==2:
                                mv_wardrobe()
                            if choice==3:
                                mv_nightstand()

############################################################################

def body():
    print(f'{t_body}')
    a_cont=a_cont+1
    if a_cont==50:
        end()
    else:
        return a_cont
        living()

def mv_sofa():
    print(f'{t_prove_knife}')
    prove_knife = prove_knife+1
    a_cont = a_cont+1
    if a_cont==50:
        end()
    else:
        return prove_knife and a_cont
        living()

def mv_bookcs():
    print(f'{t_mv_body}')
    a_cont = a_cont+1
    if a_cont==50:
        end()
    else:
        return a_cont
        living()

def mv_armchair():
    print(f'{t_note1}')
    prove_note1 = prove_note1+1
    a_cont = a_cont+1
    if a_cont==50:
        end()
    else:
        return prove_note1 and a_cont
        living()

def mv_desk():
    print(f'{t_mv_desk}')
    a_cont=a_cont+1
    if a_cont==50:
        end()
    else:
        return a_cont
        kitchen()

def mv_cabinet(room):
    a_cont=a_cont+1
    if room==2:
        print(f'{t_note2}')
        prove_note2 = prove_note2+1
        if a_cont==50:
            return prove_note2
            end() 
        else:
            return a_cont and prove_note2
            kitchen()
    else:
        print(f'{t_mv_cabinet}')
        if a_cont==50:
            end() 
        else:
            return a_cont
            bath()

def mv_cooker():
    print(f'{t_mv_cooker}')
    a_cont=a_cont+1
    if a_cont==50:
        end()
    else:
        return a_cont
        kitchen()

def mv_sink(room):
    a_cont=a_cont+1
    if room==3:
        print(f'{t_flask}')
        prove_flask = prove_flask+1
        if a_cont==50:
            return prove_flask
            end() 
        else:
            return prove_flask and a_cont
            bath()
    else:
        print(f'{t_mv_sink}')
        if a_cont==50:
            end()
        else:
            return a_cont 
            kitchen()   

def mv_bed(room):
    a_cont=a_cont+1
    if room==2:
        print(f'{t_m1911}')
        prove_m1911 = prove_m1911+1
        if a_cont==50:
            return prove_m1911
            end() 
        else:
            return prove_m1911 and a_cont
            bed2() 
    else:
        print(f'{t_mv_bed}')
        if a_cont==50:
            end()
        else:
            return a_cont
            bed1()     

def mv_wardrobe():
    print(f'{t_mv_wardrobe}')
    a_cont=a_cont+1
    if a_cont==50:
        end()
    else:
        if room==4:
            return a_cont
            bed1()
        if room==5:
            return a_cont
            bed2()

def mv_nightstand(room):
    a_cont=a_cont+1
    if room==4:
        print(f'{note3}')
        prove_note3 = prove_note3+1
        if a_cont==50:
            end()
        else:
            return a_cont and prove_note3
            bed1()
    else:
        print(f'{t_mv_nightstand}')
        if a_cont==50:
            end()
        else:
            if room==4:
                return a_cont
                bed1()
            if room==5:
                return a_cont
                bed2()

############################################################################

def proves():
    if prove_note1>0 and prove_knife>0:
        itens_end_2=1
        return itens_end_2

    elif prove_note2>0 and prove_flask>0:
        itens_end_3=1
        return itens_end_3

    elif prove_note3>0 and prove_knife>0:
        itens_end_4=1
        return itens_end_4

    elif prove_nota1>0 and prove_nota2>0 and prove_nota3>0 and prove_m1911>0 and prove_flask>0:
        itens_end_T=1
        return itens_end_T

    elif itens_end_4 == itens_end_2:
        itens_end_1=1
        return itens_end_1

    elif itens_end_2 == itens_end_3:
        itens_end_1=1
        return itens_end_1

    elif itens_end_4 == itens_end_3:
        itens_end_1=1
        return itens_end_1

    elif itens_end_4 == itens_end_3 and itens_end_4 == itens_end_2:
        itens_end_1=1
        return itens_end_1
    end()

def end(itens_end_1,itens_end_2,itens_end_3,itens_end_4,itens_end_T,):
    if itens_end_4 > itens_end_2 and itens_end_3 and itens_end_4:
        print(f'{t_end4}')
        game_over=0
        return game_over
    if itens_end_3 > itens_end_2 and itens_end_3 and itens_en_4:
        print(f'{t_end3}')
        game_over=0
        return game_over
    if itens_end_2 > itens_end_2 and itens_end_3 and itens_end_4:
        print(f'{t_end2}')
        game_over=0
        return game_over
    if itens_end_1 > itens_end_2 and itens_end_3 and itens_end_4:
        print(f'{t_end1}')
        game_over=0
        return game_over
    if itens_end_T > itens_end_1 or itens_end_2 or itens_end_3 or itens_end_4:
        print(f'{t_endT}')
        game_over=0
        return game_over

############################################################################

##Play
print(f'{t_tutorial}')
choice=int(imput(''))
if choice==6:
   game_over=0
   return game_over
else:
    intro1()

game_over=1
if game_over==0:
    break
